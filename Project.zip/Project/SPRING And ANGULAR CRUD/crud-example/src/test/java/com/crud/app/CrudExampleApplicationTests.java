package com.crud.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.crud.app.controller.UserController;
import com.crud.app.model.User;
import com.crud.app.services.UserService;
import com.google.common.base.Verify;

@SpringBootTest
class CrudExampleApplicationTests {

	@Autowired 
	private UserService use;
	
	@Test
	void contextLoads() {

	}
	@Test
	public void gettestId() {
		assertEquals(1,1);
	}
	@Before
	public void setUp() {
		User user =new User(1,"Divyanshu","Password","Admin");
		use.save(user);
	}
	@After
	public void setDown() {
		User user =null;
		System.out.println("Test Done");
	}

	@Test
	void listaltest() {
		List<User> act=use.listAll();
		assertThat(act).isNotNull();
	}
	@Test 
	void gettest()  throws Exception{
		User user =new User(1,"name","password","Admin");
		User user1 =new User(2,"nam","passkey","Normal");
		User user2=new User(3,"naam","word","Admin");
		use.save(user);
		use.save(user2);
		use.save(user1);
		User u= use.get(1);
		assertThat(u).isNotNull();
	}
	@Test
	void fetchtest() {
		User u2= use.fetchUserByUserName("name");
		assertThat(u2).isNotNull();
		User u3=use.fetchUserByUserNameAndPassword("name", "password");
		assertThat(u3).isNotNull();
	}
	@Test
	void updatetest() {
		User user =new User(3,"namey","password","Normal");
		use.update(user);
		assertThat(user).isNotNull();		
		
	}
	
	@Test 
	public boolean deletetest() throws Exception{
		use.delete(2);
		   try{
	            use.get(2);
	            return true;
	        }
	        catch(NoSuchElementException e){
	            return false;
	        }
	}
	


}
