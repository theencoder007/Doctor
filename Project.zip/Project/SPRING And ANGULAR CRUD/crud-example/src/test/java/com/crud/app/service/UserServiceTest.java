package com.crud.app.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.crud.app.controller.UserController;
import com.crud.app.model.User;
import com.crud.app.services.UserService;


public class UserServiceTest {

	@InjectMocks
	UserService manager;

	@Mock
	UserController dao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void gettestId() {
		assertEquals(1,1);
	}
	
	@Test
	public void getAllEmployeesTest()
	{
		List<User> list = new ArrayList<User>();
		User empOne = new User(1, "John", "John", "Admin");
		User empTwo = new User(2, "Alex", "kolenchiski", "ADMIN");
		User empThree = new User(3, "Steve", "Waugh", "ADMIN");

		list.add(empOne);
		list.add(empTwo);
		list.add(empThree);

		when(dao.list()).thenReturn(list);

		//test
		List<User> empList = manager.listAll();

		assertEquals(3, empList.size());
		verify(dao, times(1)).list();
	}

//	@Test
//	public void getEmployeeByIdTest()
//	{
//		when(dao.getEmployeeById(1)).thenReturn(new EmployeeVO(1,"Lokesh","Gupta","user@email.com"));
//
//		EmployeeVO emp = manager.getEmployeeById(1);
//
//		assertEquals("Lokesh", emp.getFirstName());
//		assertEquals("Gupta", emp.getLastName());
//		assertEquals("user@email.com", emp.getEmail());
//	}

	@Test
	public void createEmployeeTest()
	{
		User emp = new User(1,"Lokesh","Gupta","user@email.com");

		manager.save(emp);

		verify(dao, times(1)).add(emp);
	}
}