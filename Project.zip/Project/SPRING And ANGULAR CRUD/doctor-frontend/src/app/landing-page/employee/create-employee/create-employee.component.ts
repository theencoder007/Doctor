import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee';
import { EmployeeService } from 'src/app/service/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
    employees: Employee = new Employee();

constructor(private EmployeeService: EmployeeService, private router: Router) { }

ngOnInit(): void {
}

saveEmployee(){
  this.EmployeeService.createEmployee(this.employees).subscribe(data=>{
    console.log(data);
    this.goToUserList();
  },
  error => console.log(error));
}

goToUserList(){
  this.router.navigate(['/landing-page/employee-list'])
}

onSubmit(){
  console.log(this.employees);
  this.saveEmployee;
}
}