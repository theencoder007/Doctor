import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/model/employee';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees: Employee[];



  constructor(private EmployeeService: EmployeeService, private router: Router) { }

  ngOnInit(): void {
    this.getEmployee();
  }

  private getEmployee(){
    this.EmployeeService.getEmployeeList().subscribe(data => {
      this.employees = data;

    });
  }
  updateEmployee(id: number){
    console.log(id);
    this.router.navigate(['/landing-page/update-employee', id]);
  }

  deleteEmployee(id: number){
    this.EmployeeService.deleteEmployee(id).subscribe(
      data => {
        console.log(data);
        this.getEmployee();
      }, error => {
        console.log("Not Delete")
      }
    )
  }


}
