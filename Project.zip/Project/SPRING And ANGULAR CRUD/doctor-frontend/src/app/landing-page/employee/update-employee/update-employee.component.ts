import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {
  id: number;
  employees: Employee=new Employee();


  constructor(private EmployeeService: EmployeeService, private route: ActivatedRoute, private router:Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.EmployeeService.getEmployeeById(this.id).subscribe(
      data => {
        this.employees=data;
      }, error => console.log(error)
    );
  }




  saveEmployee(){
    this.EmployeeService.updateEmployee(this.id, this.employees).subscribe(data =>{
        this.goToEmployeeList();
    }, error => console.log(error));
  }

  goToEmployeeList(){
    this.router.navigate(['/landing-page/employee-list'])
  }

}
